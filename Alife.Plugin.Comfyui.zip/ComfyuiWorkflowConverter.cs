using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace Alife.Plugin.Comfyui;

/// <summary>
/// 将 ComfyUI UI 工作流 JSON 转为 /prompt 可用的 API 格式。
/// 也兼容已经是 API 格式的 JSON。
/// </summary>
public static class ComfyuiWorkflowConverter
{
    static readonly HashSet<string> ControlAfterGenerate =
        new(StringComparer.OrdinalIgnoreCase)
        {
            "fixed", "increment", "decrement", "randomize"
        };

    static readonly HashSet<string> SkipNodeTypes =
        new(StringComparer.OrdinalIgnoreCase)
        {
            "Note", "Reroute", "PrimitiveNode",
            "Anything Everywhere", "Anything Everywhere3",
            "Anything Everywhere?", "Prompts Everywhere",
            "Seed Everywhere", "Simple String"
        };

    static readonly HashSet<string> ConnectionTypes =
        new(StringComparer.OrdinalIgnoreCase)
        {
            "MODEL", "CLIP", "VAE", "CONDITIONING", "LATENT", "IMAGE", "MASK",
            "CONTROL_NET", "STYLE_MODEL", "CLIP_VISION", "GLIGEN",
            "UPSCALE_MODEL", "AUDIO", "WEBCAM", "PHOTOMAKER", "*"
        };

    public static bool IsApiFormat(JsonNode root)
    {
        if (root is not JsonObject obj)
            return false;

        if (obj["nodes"] is JsonArray)
            return false;

        foreach (var kv in obj)
        {
            if (!int.TryParse(kv.Key, out _))
                continue;
            if (kv.Value is JsonObject node && node["class_type"] != null)
                return true;
        }
        return false;
    }

    public static JsonObject ToApiPrompt(JsonNode root, JsonObject? objectInfo = null)
    {
        if (IsApiFormat(root))
            return (JsonObject)root.DeepClone();

        if (root is not JsonObject ui)
            throw new Exception("工作流 JSON 格式无效");

        var nodes = ui["nodes"] as JsonArray
            ?? throw new Exception("UI 工作流缺少 nodes 数组");
        var linksArr = ui["links"] as JsonArray ?? new JsonArray();

        var linkMap = new Dictionary<int, (int srcNode, int srcSlot)>();
        foreach (var linkNode in linksArr)
        {
            if (linkNode is not JsonArray link || link.Count < 5)
                continue;
            var linkId = link[0]!.GetValue<int>();
            var srcNode = link[1]!.GetValue<int>();
            var srcSlot = link[2]!.GetValue<int>();
            linkMap[linkId] = (srcNode, srcSlot);
        }

        var ueMap = new Dictionary<(int node, int slot), (int src, int srcSlot)>();
        if (ui["extra"]?["ue_links"] is JsonArray ueLinks)
        {
            foreach (var ue in ueLinks.OfType<JsonObject>())
            {
                var down = ue["downstream"]?.GetValue<int>() ?? -1;
                var downSlot = ue["downstream_slot"]?.GetValue<int>() ?? -1;
                var upStr = ue["upstream"]?.ToString();
                var upSlot = ue["upstream_slot"]?.GetValue<int>() ?? 0;
                if (down < 0 || downSlot < 0 || string.IsNullOrWhiteSpace(upStr))
                    continue;
                if (!int.TryParse(upStr, out var up))
                    continue;
                ueMap[(down, downSlot)] = (up, upSlot);
            }
        }

        var prompt = new JsonObject();

        foreach (var nodeNode in nodes.OfType<JsonObject>())
        {
            var id = nodeNode["id"]?.GetValue<int>() ?? -1;
            if (id < 0) continue;

            var mode = nodeNode["mode"]?.GetValue<int>() ?? 0;
            if (mode is 2 or 4) continue;

            var classType = nodeNode["type"]?.GetValue<string>() ?? "";
            if (string.IsNullOrWhiteSpace(classType))
                continue;
            if (SkipNodeTypes.Contains(classType))
                continue;
            if (classType.StartsWith("markdown", StringComparison.OrdinalIgnoreCase))
                continue;

            var inputsObj = new JsonObject();
            var nodeInputs = nodeNode["inputs"] as JsonArray ?? new JsonArray();
            var widgets = nodeNode["widgets_values"] as JsonArray ?? new JsonArray();

            var widgetInputNames = new List<string>();
            for (int i = 0; i < nodeInputs.Count; i++)
            {
                if (nodeInputs[i] is not JsonObject inp)
                    continue;
                var name = inp["name"]?.GetValue<string>();
                if (string.IsNullOrWhiteSpace(name))
                    continue;

                if (inp["widget"] != null)
                    widgetInputNames.Add(name);

                if (inp["link"] is JsonValue linkVal)
                {
                    int linkId;
                    try { linkId = linkVal.GetValue<int>(); }
                    catch { continue; }
                    if (linkMap.TryGetValue(linkId, out var src))
                        inputsObj[name] = new JsonArray { src.srcNode.ToString(), src.srcSlot };
                }
            }

            // UE 隐式连线
            foreach (var (key, src) in ueMap)
            {
                if (key.node != id) continue;
                if (key.slot < 0 || key.slot >= nodeInputs.Count) continue;
                if (nodeInputs[key.slot] is not JsonObject slotInp) continue;
                var slotName = slotInp["name"]?.GetValue<string>();
                if (string.IsNullOrWhiteSpace(slotName)) continue;
                if (inputsObj.ContainsKey(slotName)) continue;
                inputsObj[slotName] = new JsonArray { src.src.ToString(), src.srcSlot };
            }

            ApplyWidgets(classType, widgetInputNames, widgets, inputsObj, objectInfo);
            ApplySpecialNodeInputs(classType, nodeNode, widgets, inputsObj);

            prompt[id.ToString()] = new JsonObject
            {
                ["class_type"] = classType,
                ["inputs"] = inputsObj
            };
        }

        return prompt;
    }

    static void ApplyWidgets(
        string classType,
        List<string> widgetInputNames,
        JsonArray widgets,
        JsonObject inputsObj,
        JsonObject? objectInfo)
    {
        var ordered = ResolveWidgetOrder(classType, widgetInputNames, objectInfo);
        int wi = 0;

        foreach (var name in ordered)
        {
            if (inputsObj.ContainsKey(name))
                continue;
            if (wi >= widgets.Count)
                break;

            var val = widgets[wi];
            if (val is JsonValue jvCtrl && jvCtrl.TryGetValue<string>(out var ctrl)
                && ControlAfterGenerate.Contains(ctrl))
            {
                wi++;
                if (wi >= widgets.Count) break;
                val = widgets[wi];
            }

            wi++;

            if (val == null || (val is JsonValue jn && jn.GetValueKind() == JsonValueKind.Null))
                continue;
            if (IsLikelyUiOnlyTokenJson(val))
                continue;

            inputsObj[name] = val.DeepClone();
        }
    }

    static List<string> ResolveWidgetOrder(string classType, List<string> fallback, JsonObject? objectInfo)
    {
        if (objectInfo == null || objectInfo[classType] is not JsonObject info)
            return fallback;

        var order = new List<string>();
        var inputOrder = info["input_order"] as JsonObject;
        var required = inputOrder?["required"] as JsonArray;
        var optional = inputOrder?["optional"] as JsonArray;

        void AddFrom(JsonArray? arr)
        {
            if (arr == null) return;
            foreach (var n in arr)
            {
                var name = n?.GetValue<string>();
                if (string.IsNullOrWhiteSpace(name)) continue;
                if (IsConnectionOnlyInput(info, name)) continue;
                order.Add(name);
            }
        }

        AddFrom(required);
        AddFrom(optional);

        if (order.Count == 0)
            return fallback;

        var set = new HashSet<string>(order, StringComparer.Ordinal);
        foreach (var f in fallback)
        {
            if (!set.Contains(f) && !IsConnectionOnlyInput(info, f))
                order.Add(f);
        }
        return order;
    }

    static bool IsConnectionOnlyInput(JsonObject nodeInfo, string name)
    {
        var input = nodeInfo["input"] as JsonObject;
        JsonNode? def = null;
        if (input?["required"] is JsonObject req && req[name] != null)
            def = req[name];
        else if (input?["optional"] is JsonObject opt && opt[name] != null)
            def = opt[name];
        else if (input?["hidden"] is JsonObject hid && hid[name] != null)
            return true;

        if (def is not JsonArray arr || arr.Count == 0)
            return false;

        // combo 选项数组 => widget
        if (arr[0] is JsonArray)
            return false;

        if (arr[0] is JsonValue typeVal && typeVal.TryGetValue<string>(out var typeName))
        {
            if (typeName is "INT" or "FLOAT" or "STRING" or "BOOLEAN")
                return false;
            if (ConnectionTypes.Contains(typeName))
                return true;
            // 全大写自定义类型通常是连线
            if (typeName == typeName.ToUpperInvariant() && typeName.Length > 1)
                return true;
        }
        return false;
    }

    static bool IsLikelyUiOnlyTokenJson(JsonNode? val)
    {
        if (val is not JsonValue jv || !jv.TryGetValue<string>(out var s))
            return false;
        s = s.TrimStart();
        return s.StartsWith("[{\"id\"", StringComparison.Ordinal)
               || s.StartsWith("[{\"id\":", StringComparison.Ordinal);
    }

    static void ApplySpecialNodeInputs(
        string classType,
        JsonObject nodeNode,
        JsonArray widgets,
        JsonObject inputsObj)
    {
        if (classType.Equals("ZmlPowerLoraLoader", StringComparison.OrdinalIgnoreCase))
        {
            if (!inputsObj.ContainsKey("lora_loader_data"))
            {
                string? data = null;
                if (nodeNode["properties"]?["powerLoraLoader_data"] != null)
                    data = nodeNode["properties"]!["powerLoraLoader_data"]!.ToJsonString();
                else if (widgets.Count > 0 && widgets[0] != null)
                {
                    data = widgets[0] is JsonValue v && v.TryGetValue<string>(out var s)
                        ? s
                        : widgets[0]!.ToJsonString();
                }

                if (!string.IsNullOrWhiteSpace(data))
                    inputsObj["lora_loader_data"] = data;
            }
            return;
        }

        if (classType.Equals("WeiLinPromptUI", StringComparison.OrdinalIgnoreCase))
        {
            if (!inputsObj.ContainsKey("positive") && widgets.Count > 0)
            {
                var p = widgets[0];
                if (p != null && !IsLikelyUiOnlyTokenJson(p))
                    inputsObj["positive"] = p.DeepClone();
            }
            if (!inputsObj.ContainsKey("auto_random") && widgets.Count > 1 && widgets[1] != null)
                inputsObj["auto_random"] = widgets[1]!.DeepClone();
        }
    }

    public static void ApplyRuntimeOverrides(
        JsonObject prompt,
        string positivePrompt,
        string? negativePrompt,
        int? width,
        int? height,
        bool randomizeSeed,
        string? positiveNodeId,
        string positiveInputName,
        string? negativeNodeId,
        string negativeInputName,
        string? resolutionNodeId,
        bool isImg2Img = false)
    {
        // 优先用采样器连接关系识别正/负面节点（通用，兼容原生 CLIPTextEncode 与第三方节点）；
        // 连接关系未命中再回退启发式（WeiLinPromptUI 文本最长者 / CLIPTextEncode）。
        var (autoPosId, autoNegId) = FindPositiveAndNegativeIds(prompt);

        var posId = ResolvePromptNodeId(
            prompt, positiveNodeId, positiveInputName, autoPosId);

        if (!string.IsNullOrWhiteSpace(posId) && prompt[posId] is JsonObject posNode)
        {
            var inputs = posNode["inputs"] as JsonObject ?? new JsonObject();
            posNode["inputs"] = inputs;
            var field = ResolvePromptField(inputs, positiveInputName);
            inputs[field] = positivePrompt;
        }
        else
        {
            throw new Exception("未找到正向提示词节点，请在配置中指定 PositivePromptNodeId，或点击 UI 的「自动识别节点」");
        }

        // 负面提示词（可选）。留空则保留工作流自带的负面
        if (!string.IsNullOrWhiteSpace(negativePrompt))
        {
            var negId = ResolvePromptNodeId(
                prompt, negativeNodeId, negativeInputName, autoNegId);

            if (!string.IsNullOrWhiteSpace(negId) && prompt[negId] is JsonObject negNode)
            {
                var inputs = negNode["inputs"] as JsonObject ?? new JsonObject();
                negNode["inputs"] = inputs;
                var field = ResolvePromptField(inputs, negativeInputName);
                inputs[field] = negativePrompt;
            }
        }

        if (width.HasValue || height.HasValue)
        {
            // 图生图模式：缩放输入图片到目标分辨率，不动 EmptyLatentImage
            if (isImg2Img)
            {
                var resizeId = FindImageResizeNodeId(prompt);
                if (!string.IsNullOrWhiteSpace(resizeId) && prompt[resizeId] is JsonObject resizeNode)
                {
                    var inputs = resizeNode["inputs"] as JsonObject ?? new JsonObject();
                    resizeNode["inputs"] = inputs;
                    // ImageResize / ImageScale 常见字段名
                    if (width.HasValue)
                    {
                        if (inputs.ContainsKey("width")) inputs["width"] = width.Value;
                        else if (inputs.ContainsKey("target_width")) inputs["target_width"] = width.Value;
                        else if (inputs.ContainsKey("W")) inputs["W"] = width.Value;
                    }
                    if (height.HasValue)
                    {
                        if (inputs.ContainsKey("height")) inputs["height"] = height.Value;
                        else if (inputs.ContainsKey("target_height")) inputs["target_height"] = height.Value;
                        else if (inputs.ContainsKey("H")) inputs["H"] = height.Value;
                    }
                }
            }
            else
            {
            var resId = resolutionNodeId;
            if (string.IsNullOrWhiteSpace(resId)
                || prompt[resId] is not JsonObject configuredResolution
                || !CanApplyResolution(configuredResolution))
                resId = FindResolutionNodeId(prompt);

            if (!string.IsNullOrWhiteSpace(resId) && prompt[resId] is JsonObject resNode)
            {
                var inputs = resNode["inputs"] as JsonObject ?? new JsonObject();
                resNode["inputs"] = inputs;
                var classType = resNode["class_type"]?.GetValue<string>() ?? "";

                if (classType.Contains("PresetResolution", StringComparison.OrdinalIgnoreCase)
                    || classType.Equals("ZML_PresetResolutionV2", StringComparison.OrdinalIgnoreCase))
                {
                    inputs["预设"] = "自定义";
                    if (width.HasValue) inputs["自定义宽"] = width.Value;
                    if (height.HasValue) inputs["自定义高"] = height.Value;
                }
                else if (classType.Contains("EmptyLatent", StringComparison.OrdinalIgnoreCase))
                {
                    if (width.HasValue) inputs["width"] = width.Value;
                    if (height.HasValue) inputs["height"] = height.Value;
                }
                else
                {
                    if (width.HasValue)
                    {
                        if (inputs.ContainsKey("width")) inputs["width"] = width.Value;
                        else if (inputs.ContainsKey("自定义宽")) inputs["自定义宽"] = width.Value;
                    }
                    if (height.HasValue)
                    {
                        if (inputs.ContainsKey("height")) inputs["height"] = height.Value;
                        else if (inputs.ContainsKey("自定义高")) inputs["自定义高"] = height.Value;
                    }
                }
            }
            } // end else (not img2img)
        } // end if (width || height)

        if (randomizeSeed)
        {
            foreach (var kv in prompt)
            {
                if (kv.Value is not JsonObject node) continue;
                if (node["inputs"] is not JsonObject inputs) continue;
                if (inputs.ContainsKey("seed"))
                    inputs["seed"] = Random.Shared.NextInt64(0, long.MaxValue);
                if (inputs.ContainsKey("noise_seed"))
                    inputs["noise_seed"] = Random.Shared.NextInt64(0, long.MaxValue);
            }
        }
    }

    static readonly HashSet<string> SamplerTypes =
        new(StringComparer.OrdinalIgnoreCase)
        {
            "KSampler", "KSamplerAdvanced", "KSampler (Efficient)",
            "SamplerCustom", "SamplerCustomAdvanced", "KSampler Turbo",
            "KSampler Select", "KSampler (Advanced)"
        };

    static bool IsSamplerType(string ct)
        => SamplerTypes.Contains(ct) || ct.Contains("Sampler", StringComparison.OrdinalIgnoreCase);

    static bool IsUsablePromptNode(JsonObject prompt, string? nodeId, string? inputName)
    {
        if (string.IsNullOrWhiteSpace(nodeId) || prompt[nodeId] is not JsonObject node)
            return false;

        var classType = node["class_type"]?.GetValue<string>() ?? "";
        var inputs = node["inputs"] as JsonObject;
        if (inputs == null)
            return false;

        if (IsPromptTextNode(classType))
            return true;

        if (!string.IsNullOrWhiteSpace(inputName)
            && inputs[inputName] is JsonValue configuredValue
            && configuredValue.TryGetValue<string>(out _))
            return true;

        return inputs["text"] is JsonValue text && text.TryGetValue<string>(out _)
               || inputs["positive"] is JsonValue positive && positive.TryGetValue<string>(out _);
    }

    static string? ResolvePromptNodeId(
        JsonObject prompt,
        string? configuredId,
        string? configuredInputName,
        string? autoId)
    {
        if (IsUsablePromptNode(prompt, configuredId, configuredInputName))
            return configuredId;
        return IsUsablePromptNode(prompt, autoId, null) ? autoId : null;
    }

    static bool CanApplyResolution(JsonObject node)
    {
        var classType = node["class_type"]?.GetValue<string>() ?? "";
        if (classType.Contains("PresetResolution", StringComparison.OrdinalIgnoreCase)
            || classType.Contains("EmptyLatent", StringComparison.OrdinalIgnoreCase))
            return true;

        var inputs = node["inputs"] as JsonObject;
        return inputs != null
               && (inputs.ContainsKey("width") || inputs.ContainsKey("height")
                   || inputs.ContainsKey("自定义宽") || inputs.ContainsKey("自定义高"));
    }

    static bool IsPromptTextNode(string ct)
        => ct.Contains("TextEncode", StringComparison.OrdinalIgnoreCase)
           || ct.Contains("PromptUI", StringComparison.OrdinalIgnoreCase)
           || ct.Contains("PromptText", StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// 通过采样器 positive/negative 输入的连接关系识别正/负面提示词节点。
    /// 对原生 ComfyUI 工作流（CLIPTextEncode）与第三方节点（WeiLinPromptUI 等）均通用。
    /// 连接关系未命中时回退到启发式。
    /// </summary>
    public static (string? positiveId, string? negativeId) FindPositiveAndNegativeIds(JsonObject prompt)
    {
        string? posId = null, negId = null;

        foreach (var kv in prompt)
        {
            if (kv.Value is not JsonObject node) continue;
            var ct = node["class_type"]?.GetValue<string>() ?? "";
            if (!IsSamplerType(ct)) continue;
            var inputs = node["inputs"] as JsonObject;
            if (inputs == null) continue;

            if (posId == null && inputs["positive"] is JsonArray pArr && pArr.Count > 0)
                posId = pArr[0]?.GetValue<string>();
            if (negId == null && inputs["negative"] is JsonArray nArr && nArr.Count > 0)
                negId = nArr[0]?.GetValue<string>();
        }

        // 采样器直连的节点可能不是文本节点（如 ConditionCombine），沿连接图递归追溯。
        posId = TraceToPromptNode(prompt, posId, preferNegative: false);
        negId = TraceToPromptNode(prompt, negId, preferNegative: true);

        // 连接关系未命中，回退启发式
        posId ??= FindPositiveNodeId(prompt);
        negId ??= FindNegativeNodeId(prompt, posId);
        return (posId, negId);
    }

    static string? TraceToPromptNode(
        JsonObject prompt, string? startId, bool preferNegative)
    {
        if (string.IsNullOrWhiteSpace(startId))
            return null;

        var queue = new Queue<string>();
        var visited = new HashSet<string>(StringComparer.Ordinal);
        queue.Enqueue(startId);

        while (queue.Count > 0)
        {
            var currentId = queue.Dequeue();
            if (!visited.Add(currentId) || prompt[currentId] is not JsonObject node)
                continue;

            var classType = node["class_type"]?.GetValue<string>() ?? "";
            if (IsPromptTextNode(classType))
                return currentId;

            if (node["inputs"] is not JsonObject inputs)
                continue;

            // Conditioning 组合节点常同时包含 positive/negative，优先沿语义相符的分支追踪。
            var linkedInputs = inputs
                .Where(kv => kv.Value is JsonArray arr
                             && arr.Count > 0
                             && arr[0] is JsonValue)
                .OrderByDescending(kv => IsPreferredConditioningInput(kv.Key, preferNegative));

            foreach (var input in linkedInputs)
            {
                if (input.Value is not JsonArray arr || arr.Count == 0)
                    continue;
                string? linkedId = null;
                try { linkedId = arr[0]?.GetValue<string>(); }
                catch { }
                if (!string.IsNullOrWhiteSpace(linkedId) && !visited.Contains(linkedId))
                    queue.Enqueue(linkedId);
            }
        }

        return null;
    }

    static bool IsPreferredConditioningInput(string name, bool preferNegative)
    {
        if (preferNegative)
            return name.Contains("negative", StringComparison.OrdinalIgnoreCase)
                   || name.Contains("负", StringComparison.OrdinalIgnoreCase);
        return name.Contains("positive", StringComparison.OrdinalIgnoreCase)
               || name.Contains("正", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// 解析提示词文本字段名。配置留空时按节点 inputs 自动选择：
    /// 优先 text（CLIPTextEncode），其次 positive（WeiLinPromptUI），再取第一个字符串字段。
    /// </summary>
    public static string ResolvePromptField(JsonObject inputs, string? configuredName)
    {
        if (!string.IsNullOrWhiteSpace(configuredName) && inputs.ContainsKey(configuredName))
            return configuredName;

        if (inputs.ContainsKey("text")) return "text";
        if (inputs.ContainsKey("positive")) return "positive";
        foreach (var kv in inputs)
        {
            if (kv.Value is JsonValue v && v.TryGetValue<string>(out _))
                return kv.Key;
        }
        return !string.IsNullOrWhiteSpace(configuredName) ? configuredName : "positive";
    }

    public static string? FindPositiveNodeId(JsonObject prompt)
    {
        string? bestWeiLin = null;
        int bestLen = -1;
        string? promptTextNode = null;

        foreach (var kv in prompt)
        {
            if (kv.Value is not JsonObject node) continue;
            var ct = node["class_type"]?.GetValue<string>() ?? "";
            var inputs = node["inputs"] as JsonObject;

            if (ct.Equals("WeiLinPromptUI", StringComparison.OrdinalIgnoreCase))
            {
                var text = inputs?["positive"]?.ToString() ?? "";
                if (text.Length > bestLen)
                {
                    bestLen = text.Length;
                    bestWeiLin = kv.Key;
                }
            }
            else if (IsPromptTextNode(ct) && promptTextNode == null)
            {
                promptTextNode = kv.Key;
            }
        }

        return bestWeiLin ?? promptTextNode;
    }

    /// <summary>
    /// 找负面提示词节点：优先正向节点之外的另一个 WeiLinPromptUI（文本最短者），
    /// 其次是另一个 CLIPTextEncode。
    /// </summary>
    public static string? FindNegativeNodeId(JsonObject prompt, string? excludePosId)
    {
        string? bestWeiLin = null;
        int bestLen = int.MaxValue;
        string? promptTextNode = null;

        foreach (var kv in prompt)
        {
            if (!string.IsNullOrEmpty(excludePosId) && kv.Key == excludePosId) continue;
            if (kv.Value is not JsonObject node) continue;
            var ct = node["class_type"]?.GetValue<string>() ?? "";
            var inputs = node["inputs"] as JsonObject;

            if (ct.Equals("WeiLinPromptUI", StringComparison.OrdinalIgnoreCase))
            {
                var text = inputs?["positive"]?.ToString() ?? "";
                if (text.Length < bestLen)
                {
                    bestLen = text.Length;
                    bestWeiLin = kv.Key;
                }
            }
            else if (IsPromptTextNode(ct) && promptTextNode == null)
            {
                promptTextNode = kv.Key;
            }
        }

        return bestWeiLin ?? promptTextNode;
    }

    public static string? FindResolutionNodeId(JsonObject prompt)
    {
        foreach (var kv in prompt)
        {
            if (kv.Value is not JsonObject node) continue;
            var ct = node["class_type"]?.GetValue<string>() ?? "";
            if (ct.Contains("PresetResolution", StringComparison.OrdinalIgnoreCase)
                || ct.Equals("ZML_PresetResolutionV2", StringComparison.OrdinalIgnoreCase)
                || ct.Contains("EmptyLatent", StringComparison.OrdinalIgnoreCase))
                return kv.Key;
        }
        return null;
    }

    // ===================== AI 节点控制 =====================

    static readonly HashSet<string> AiVisibleNodeFields = new(StringComparer.OrdinalIgnoreCase)
    {
        "ckpt_name", "steps", "cfg", "cfg_scale", "sampler_name", "scheduler",
        "denoise", "batch_size", "width", "height"
    };

    static readonly string[] SensitiveOverrideFragments =
    {
        "path", "save", "directory", "url", "command", "script", "token", "password",
        "filename", "file_name", "保存", "路径", "目录", "地址", "命令", "脚本", "令牌", "密码"
    };

    /// <summary>按需描述允许 AI 操作的安全标量参数。</summary>
    public static string BuildNodeControlDescription(JsonObject prompt)
    {
        var lines = new List<string>();

        foreach (var kv in prompt)
        {
            if (lines.Count >= 40) break;
            if (kv.Value is not JsonObject node) continue;
            var ct = node["class_type"]?.GetValue<string>() ?? "";
            var inputs = node["inputs"] as JsonObject;
            if (inputs == null || inputs.Count == 0) continue;

            var widgets = new List<string>();
            foreach (var ikv in inputs)
            {
                if (widgets.Count >= 10) break;
                if (!AiVisibleNodeFields.Contains(ikv.Key) || ikv.Value is not JsonValue)
                    continue;
                var valStr = ikv.Value.ToString();
                if (valStr.Length > 80) valStr = valStr[..77] + "...";
                widgets.Add($"{ikv.Key}={valStr}");
            }

            if (widgets.Count == 0) continue;

            lines.Add($"· 节点 #{kv.Key} [{ct}]: {string.Join(", ", widgets)}");
        }

        if (lines.Count == 0) return "当前工作流无可调节点。";

        return "允许调整的节点参数：\n" + string.Join("\n", lines);
    }

    /// <summary>
    /// 将 AI 传入的语义化参数注入到工作流对应节点中。
    /// 支持 model / steps / cfg / sampler / scheduler / denoise / batch_size，
    /// 以及 rawOverrides JSON（兜底：按节点 ID 直接覆盖 input 值）。
    /// </summary>
    public static void ApplyNodeOverrides(
        JsonObject prompt,
        string? model = null,
        int? steps = null,
        double? cfg = null,
        string? sampler = null,
        string? scheduler = null,
        double? denoise = null,
        int? batch_size = null,
        string? rawOverrides = null)
    {
        ValidateSemanticOverrides(model, steps, cfg, sampler, scheduler, denoise, batch_size);

        foreach (var kv in prompt)
        {
            if (kv.Value is not JsonObject node) continue;
            var ct = node["class_type"]?.GetValue<string>() ?? "";
            var inputs = node["inputs"] as JsonObject;
            if (inputs == null) continue;

            // 模型切换：CheckpointLoader / CheckpointLoaderSimple
            if (!string.IsNullOrWhiteSpace(model) && IsCheckpointLoader(ct))
            {
                var key = inputs.ContainsKey("ckpt_name") ? "ckpt_name" : null;
                if (key == null)
                {
                    foreach (var ikv in inputs)
                    {
                        if (ikv.Value is JsonValue jv && jv.TryGetValue<string>(out var s)
                            && (s.EndsWith(".safetensors", StringComparison.OrdinalIgnoreCase)
                                || s.EndsWith(".ckpt", StringComparison.OrdinalIgnoreCase)))
                        { key = ikv.Key; break; }
                    }
                }
                if (key != null) inputs[key] = model;
            }

            // 采样器参数：KSampler / KSamplerAdvanced / 等
            if (IsSamplerType(ct))
            {
                if (steps.HasValue && inputs.ContainsKey("steps"))
                    inputs["steps"] = steps.Value;
                if (cfg.HasValue)
                {
                    if (inputs.ContainsKey("cfg")) inputs["cfg"] = cfg.Value;
                    else if (inputs.ContainsKey("cfg_scale")) inputs["cfg_scale"] = cfg.Value;
                }
                if (!string.IsNullOrWhiteSpace(sampler) && inputs.ContainsKey("sampler_name"))
                    inputs["sampler_name"] = sampler;
                if (!string.IsNullOrWhiteSpace(scheduler) && inputs.ContainsKey("scheduler"))
                    inputs["scheduler"] = scheduler;
                if (denoise.HasValue && inputs.ContainsKey("denoise"))
                    inputs["denoise"] = denoise.Value;
            }

            // 批次大小：EmptyLatentImage
            if (batch_size.HasValue && ct.Contains("EmptyLatent", StringComparison.OrdinalIgnoreCase))
            {
                if (inputs.ContainsKey("batch_size"))
                    inputs["batch_size"] = batch_size.Value;
            }
        }

        // 原始覆盖仅允许现有节点的现有标量字段，禁止连线和路径类参数。
        if (!string.IsNullOrWhiteSpace(rawOverrides))
            ApplyValidatedRawOverrides(prompt, rawOverrides);
    }

    static void ValidateSemanticOverrides(
        string? model, int? steps, double? cfg, string? sampler, string? scheduler,
        double? denoise, int? batch_size)
    {
        if (model?.Length > 260)
            throw new ArgumentOutOfRangeException(nameof(model), "模型名称过长");
        if (sampler?.Length > 80)
            throw new ArgumentOutOfRangeException(nameof(sampler), "采样器名称过长");
        if (scheduler?.Length > 80)
            throw new ArgumentOutOfRangeException(nameof(scheduler), "调度器名称过长");
        if (steps is < 1 or > 200)
            throw new ArgumentOutOfRangeException(nameof(steps), "steps 必须在 1~200 之间");
        if (cfg is < 0 or > 30)
            throw new ArgumentOutOfRangeException(nameof(cfg), "cfg 必须在 0~30 之间");
        if (denoise is < 0 or > 1)
            throw new ArgumentOutOfRangeException(nameof(denoise), "denoise 必须在 0~1 之间");
        if (batch_size is < 1 or > 16)
            throw new ArgumentOutOfRangeException(nameof(batch_size), "batch_size 必须在 1~16 之间");
    }

    static void ApplyValidatedRawOverrides(JsonObject prompt, string rawOverrides)
    {
        if (rawOverrides.Length > 8192)
            throw new ArgumentException("nodeOverrides 不能超过 8192 个字符", nameof(rawOverrides));

        JsonObject overrides;
        try
        {
            overrides = JsonNode.Parse(rawOverrides) as JsonObject
                ?? throw new ArgumentException("nodeOverrides 顶层必须是 JSON 对象");
        }
        catch (JsonException ex)
        {
            throw new ArgumentException($"nodeOverrides JSON 无效: {ex.Message}", nameof(rawOverrides));
        }

        var pending = new List<(JsonObject Inputs, string Field, JsonNode Value)>();
        var overrideCount = 0;
        foreach (var nodeOverride in overrides)
        {
            if (prompt[nodeOverride.Key] is not JsonObject targetNode)
                throw new ArgumentException($"nodeOverrides 包含不存在的节点 #{nodeOverride.Key}");
            if (targetNode["inputs"] is not JsonObject targetInputs)
                throw new ArgumentException($"节点 #{nodeOverride.Key} 没有可覆盖的 inputs");
            if (nodeOverride.Value is not JsonObject fields)
                throw new ArgumentException($"节点 #{nodeOverride.Key} 的覆盖值必须是 JSON 对象");

            foreach (var fieldOverride in fields)
            {
                if (++overrideCount > 32)
                    throw new ArgumentException("nodeOverrides 最多允许 32 个字段");
                if (IsSensitiveOverrideField(fieldOverride.Key))
                    throw new ArgumentException($"禁止覆盖敏感字段 #{nodeOverride.Key}.{fieldOverride.Key}");
                if (!targetInputs.TryGetPropertyValue(fieldOverride.Key, out var currentValue))
                    throw new ArgumentException($"节点 #{nodeOverride.Key} 不存在字段 {fieldOverride.Key}");
                if (currentValue is not JsonValue || fieldOverride.Value is not JsonValue newValue)
                    throw new ArgumentException(
                        $"#{nodeOverride.Key}.{fieldOverride.Key} 只允许标量值，不能修改连线、对象或数组");
                if (!AreCompatibleScalarTypes(currentValue, newValue))
                    throw new ArgumentException($"#{nodeOverride.Key}.{fieldOverride.Key} 的值类型不匹配");
                if (newValue.GetValueKind() == JsonValueKind.String
                    && (newValue.GetValue<string>()?.Length ?? 0) > 512)
                    throw new ArgumentException($"#{nodeOverride.Key}.{fieldOverride.Key} 的字符串值过长");

                ValidateKnownRawRange(fieldOverride.Key, newValue);
                pending.Add((targetInputs, fieldOverride.Key, newValue.DeepClone()));
            }
        }

        foreach (var change in pending)
            change.Inputs[change.Field] = change.Value;
    }

    static bool IsSensitiveOverrideField(string field)
        => SensitiveOverrideFragments.Any(fragment =>
            field.Contains(fragment, StringComparison.OrdinalIgnoreCase));

    static bool AreCompatibleScalarTypes(JsonNode currentValue, JsonValue newValue)
    {
        var currentKind = currentValue.GetValueKind();
        var newKind = newValue.GetValueKind();
        if (currentKind is JsonValueKind.True or JsonValueKind.False)
            return newKind is JsonValueKind.True or JsonValueKind.False;
        return currentKind == newKind
               && currentKind is JsonValueKind.String or JsonValueKind.Number;
    }

    static void ValidateKnownRawRange(string field, JsonValue value)
    {
        if (value.GetValueKind() != JsonValueKind.Number)
            return;

        var number = value.GetValue<double>();
        if (field.Equals("steps", StringComparison.OrdinalIgnoreCase) && number is < 1 or > 200)
            throw new ArgumentOutOfRangeException(field, "steps 必须在 1~200 之间");
        if ((field.Equals("cfg", StringComparison.OrdinalIgnoreCase)
             || field.Equals("cfg_scale", StringComparison.OrdinalIgnoreCase))
            && number is < 0 or > 30)
            throw new ArgumentOutOfRangeException(field, "cfg 必须在 0~30 之间");
        if (field.Equals("denoise", StringComparison.OrdinalIgnoreCase) && number is < 0 or > 1)
            throw new ArgumentOutOfRangeException(field, "denoise 必须在 0~1 之间");
        if (field.Equals("batch_size", StringComparison.OrdinalIgnoreCase) && number is < 1 or > 16)
            throw new ArgumentOutOfRangeException(field, "batch_size 必须在 1~16 之间");
        if ((field.Equals("width", StringComparison.OrdinalIgnoreCase)
             || field.Equals("height", StringComparison.OrdinalIgnoreCase))
            && number is < 64 or > 4096)
            throw new ArgumentOutOfRangeException(field, "width/height 必须在 64~4096 之间");
    }

    static bool IsCheckpointLoader(string classType)
        => classType.Contains("CheckpointLoader", StringComparison.OrdinalIgnoreCase)
           || classType.Contains("Checkpoint", StringComparison.OrdinalIgnoreCase)
               && classType.Contains("Loader", StringComparison.OrdinalIgnoreCase);

    // ===================== 图生图图片输入 =====================

    /// <summary>
    /// 自动识别工作流中的 LoadImage 节点 ID。
    /// class_type 包含 "LoadImage" 或 "Load Image" 即命中。
    /// </summary>
    public static string? FindLoadImageNodeId(JsonObject prompt)
    {
        foreach (var kv in prompt)
        {
            if (kv.Value is not JsonObject node) continue;
            var ct = node["class_type"]?.GetValue<string>() ?? "";
            if (ct.Contains("LoadImage", StringComparison.OrdinalIgnoreCase)
                || ct.Contains("Load Image", StringComparison.OrdinalIgnoreCase))
                return kv.Key;
        }
        return null;
    }

    /// <summary>
    /// 将已上传的图片文件名注入到 LoadImage 节点。
    /// </summary>
    public static string? InjectLoadImage(JsonObject prompt, string? nodeId, string inputName, string filename)
    {
        var nid = IsUsableLoadImageNode(prompt, nodeId, inputName)
            ? nodeId
            : FindLoadImageNodeId(prompt);
        if (string.IsNullOrWhiteSpace(nid) || prompt[nid] is not JsonObject node)
            return null;

        var inputs = node["inputs"] as JsonObject ?? new JsonObject();
        node["inputs"] = inputs;
        var field = ResolveLoadImageField(inputs, inputName);
        inputs[field] = filename;
        return nid;
    }

    static bool IsUsableLoadImageNode(JsonObject prompt, string? nodeId, string? inputName)
    {
        if (string.IsNullOrWhiteSpace(nodeId) || prompt[nodeId] is not JsonObject node)
            return false;

        var classType = node["class_type"]?.GetValue<string>() ?? "";
        if (classType.Contains("LoadImage", StringComparison.OrdinalIgnoreCase)
            || classType.Contains("Load Image", StringComparison.OrdinalIgnoreCase))
            return true;

        var inputs = node["inputs"] as JsonObject;
        return inputs != null
               && !string.IsNullOrWhiteSpace(inputName)
               && inputs[inputName] is JsonValue value
               && value.TryGetValue<string>(out _);
    }

    static string ResolveLoadImageField(JsonObject inputs, string? configuredName)
    {
        if (!string.IsNullOrWhiteSpace(configuredName)
            && inputs[configuredName] is JsonValue configuredValue
            && configuredValue.TryGetValue<string>(out _))
            return configuredName;

        foreach (var candidate in new[] { "image", "filename", "image_path", "path" })
        {
            if (inputs[candidate] is JsonValue value && value.TryGetValue<string>(out _))
                return candidate;
        }

        foreach (var input in inputs)
        {
            if (input.Value is JsonValue value && value.TryGetValue<string>(out _))
                return input.Key;
        }

        return string.IsNullOrWhiteSpace(configuredName) ? "image" : configuredName;
    }

    /// <summary>
    /// 自动识别工作流中的 ImageResize / ImageScale 节点 ID。
    /// 用于图生图模式时将输出分辨率注入到缩放节点。
    /// </summary>
    public static string? FindImageResizeNodeId(JsonObject prompt)
    {
        foreach (var kv in prompt)
        {
            if (kv.Value is not JsonObject node) continue;
            var ct = node["class_type"]?.GetValue<string>() ?? "";
            if (ct.Contains("ImageResize", StringComparison.OrdinalIgnoreCase)
                || ct.Contains("ImageScale", StringComparison.OrdinalIgnoreCase)
                || ct.Contains("ImageResizeToTotalPixels", StringComparison.OrdinalIgnoreCase))
                return kv.Key;
        }
        return null;
    }
}
